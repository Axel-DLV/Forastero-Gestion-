# botanero-ventas
 Sistema para un restaurante, local donde vendan comida, botanas, etc.
